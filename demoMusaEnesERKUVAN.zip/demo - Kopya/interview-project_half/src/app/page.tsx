"use client";
import styles from "./page.module.css";

export default function Home() {


    var changeList = []

  const onBackButtonClick = () => {

        if (changeList.length){

            var poppedDivNode =changeList.pop()
            console.log("Popped Div node ",poppedDivNode)

            if (poppedDivNode.querySelector('p').textContent === "X")
                poppedDivNode.querySelector('p').textContent = "";
            else{
                poppedDivNode.querySelector('p').textContent = "X";
            }
        }
        else {
            alert("geri alınacak bir hamle yok.")
        }
   
  };

  const onSquareClick = (event) => {

      if (event.currentTarget.querySelector('p').textContent === "X")
          event.currentTarget.querySelector('p').textContent = "";
      else{
          event.currentTarget.querySelector('p').textContent = "X";
      }

      changeList.push(event.currentTarget)

      console.log("ChangeList Array ",changeList)

  };

  return (
    <main className={styles.main}>
      <button className={styles.backButton} onClick={onBackButtonClick}>
        GERİ AL
      </button>

      <div className={styles.squareContainer}>

        <div  className={styles.square} onClick={onSquareClick}>
            <p></p>
        </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>

          <div  className={styles.square} onClick={onSquareClick}>
              <p></p>
          </div>


      </div>

    
    </main>
  );
}
